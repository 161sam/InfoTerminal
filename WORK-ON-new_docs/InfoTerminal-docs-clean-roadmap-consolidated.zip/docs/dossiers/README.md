Dossier templates overview.
