# ADR {NNNN}: {Title}

Date: YYYY-MM-DD

## Status

Proposed | Accepted | Deprecated | Superseded by ADR-XXXX

## Context

{Problem / forces}

## Decision

{What and why}

## Consequences

{Positive/negative, trade-offs}

## Alternatives

{Considered options}

## References

{Links}
