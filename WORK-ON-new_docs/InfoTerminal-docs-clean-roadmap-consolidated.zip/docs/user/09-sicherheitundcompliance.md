# 9. Sicherheit & Compliance

Sicherheit, Nachvollziehbarkeit und verantwortungsvolle Nutzung von KI sind **Kernprinzipien** von InfoTerminal.
Alle Mechanismen sind so gestaltet, dass sie **technisch robust** und **rechtlich konform** einsetzbar sind – in Unternehmen, Behörden und Forschung.

---

## 9.1 Zugriffskontrolle

InfoTerminal setzt auf **moderne Standards für Authentifizierung und Autorisierung**:

- **OAuth2 / OIDC** → Integration mit gängigen Providern (Keycloak, Auth0, GitHub, Azure AD)
- **Role-Based Access Control (RBAC)** → Nutzerrollen (z. B. Analyst, Admin, Auditor)
- **Row-Level Security (RLS)** → Datenbankfilterung auf Ebene einzelner Datensätze
- **OPA (Open Policy Agent)** → Validierung aller Zugriffe gegen zentrale Sicherheitsrichtlinien

👉 Damit wird sichergestellt, dass **jeder Zugriff nachvollziehbar und regelkonform** ist.

---

## 9.2 Audit Logs & Nachvollziehbarkeit

Alle Aktionen in InfoTerminal werden **vollständig protokolliert**:

- **Audit Logs** enthalten: Nutzer-ID, Zeitstempel, Aktion, Zielsystem
- **Dual-Plane Logging**:
  - _Persistent Logs_ → für Compliance & Revision
  - _Ephemeral Logs_ → flüchtige Session-Analysen, die nach Ende gelöscht werden

👉 Jede Analyse ist **transparent dokumentiert** – ein entscheidender Vorteil für Governance & Forensik.

---

## 9.3 Ethical AI

InfoTerminal integriert Mechanismen für **faire & nachvollziehbare KI**:

- **Bias-Checks** → Erkennung von Verzerrungen in Modellen & Trainingsdaten
- **Model Cards** → Dokumentation von Fähigkeiten, Einschränkungen und Anwendungsbereichen
- **Human-in-the-loop** → Nutzer behalten stets die letzte Entscheidungshoheit
- **Explainability** → Modelle liefern Begründungen für Ergebnisse, nicht nur Ergebnisse

👉 KI wird nicht als Blackbox verstanden, sondern als **Werkzeug mit Rechenschaftspflicht**.

---

## 9.4 Nachhaltigkeit

Ein Alleinstellungsmerkmal von InfoTerminal ist der Fokus auf **Green IT**:

- **Energieeffiziente ML-Modelle** → ressourcenschonend trainiert & optimiert
- **Nachhaltige Infrastruktur** → Green Hosting & erneuerbare Energiequellen bevorzugt
- **Föderierte Deployments** → Daten bleiben dezentral, Übertragungen werden reduziert
- **DAO-ready Architektur** → gemeinschaftlich gesteuerte Infrastruktur möglich

👉 InfoTerminal ist nicht nur technisch stark, sondern auch **ökologisch zukunftsfähig**.

---

## 9.5 Compliance-Standards

InfoTerminal orientiert sich an internationalen Standards:

- **DSGVO/GDPR** → volle Datenschutzkonformität in Europa
- **ISO 27001** → Informationssicherheitsmanagement
- **NIS2** → Richtlinien für Netz- und Informationssicherheit
- **AI Act (EU)** → vorbereitete Mechanismen für KI-Governance

---
