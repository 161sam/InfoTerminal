# Integrations

n8n, NiFi, WaveTerm and Export integrations.
- [EXPORT](export/AFFINE.md)
- [N8N](n8n/flowise_n8n.md)
- [NIFI](nifi/WaveTermInvoker.md)
- [WAVETERM](waveterm/README.md)
