# InfoTerminal Documentation

Schnellzugriffe:

- [User](user/)
- [Dev](dev/)
- [Adr](adr/)
- [Architecture](architecture/)
- [Blueprints](blueprints/)
- [Presets](presets/)
- [Dossiers](dossiers/)
- [Integrations](integrations/)
- [Api](api/)
- [Runbooks](runbooks/)
- [Screenshots](screenshots/)

> User-Docs: **Deutsch**; Dev/API: **Englisch**.
