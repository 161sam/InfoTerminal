# Presets & Profiles

Profiles for different analyst personas.
- [Agency](profile-agency.yaml)
- [Climate Researcher](profile-climate-researcher.yaml)
- [Compliance Officer](profile-compliance-officer.yaml)
- [Crisis Analyst](profile-crisis-analyst.yaml)
- [Disinfo Watchdog](profile-disinfo-watchdog.yaml)
- [Economic Analyst](profile-economic-analyst.yaml)
- [Journalism](profile-journalism.yaml)
- [Research](profile-research.yaml)
