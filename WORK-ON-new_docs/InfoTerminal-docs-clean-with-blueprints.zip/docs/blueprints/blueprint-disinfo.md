---
status: draft
owner: team-intel
last_updated: 2025-09-09
inputs:
  - Social Media APIs (Twitter/X, Facebook, Telegram, etc.)
  - RSS Feeds & News-Plattformen
  - Archivdatenbanken & Fact-Check-Portale
pipelines:
  - Ingest (NiFi: Feeds, APIs, Webcrawler)
  - NLP: Named Entity Recognition (NER)
  - Relation Extraction, Stance Detection, RTE
  - Graph-Clustering & Community Detection
  - Evidence Aggregation & Reranking
outputs:
  - Evidence Reports (Dossiers)
  - Veracity Badges in Frontend
  - Alerts via n8n Playbooks
privacy_ethics:
  - Minimierung personenbezogener Daten (PII)
  - DSGVO-konformes Logging & Retention
  - Quellenbewertung (Bias, Reputation)
kpis:
  - Precision/Recall bei Fake-News Detection
  - Time-to-Detection (Δ zwischen Erstveröffentlichung und Erkennung)
  - Anzahl verifizierter Claims pro Zeitraum
---

# Blueprint: Disinformation Intelligence

## Ziel
Früherkennung und Analyse koordinierter Desinformationskampagnen in Social Media und Nachrichtenplattformen.

## Eingaben (Inputs)
- Social Media Streams (APIs, Bots, Channel-Feeds)  
- Newsfeeds, Blogs, RSSHub  
- Archivdatenbanken und Fact-Checking-Portale  

## Verarbeitung (Pipeline)
1. **Ingest**: Sammeln von Nachrichten & Posts via NiFi  
2. **NLP**: Entitäten extrahieren (Personen, Organisationen, Orte)  
3. **Verifikation**: Relation Extraction, Stance Classification, RTE  
4. **Graph-Analyse**: Clusterbildung, Bot-Likelihood, Source-Reputation  
5. **Aggregation**: Evidenzen bündeln, Reranking  

## Ergebnisse (Outputs)
- Evidenz-Panel im Frontend  
- Dossiers für Claims & Quellen  
- Echtzeit-Alerts (n8n, Webhooks)  

## KPIs & Erfolgskriterien
- Erkennungsgenauigkeit (Precision/Recall)  
- Geschwindigkeit der Detektion  
- Abdeckung der wichtigsten Social Media Kanäle  

## Datenschutz & Ethik
- Strenge PII-Filterung  
- Bias-Checks in Modellen  
- Auditierbare Pipeline-Logs  

## Beispiel / Minimal Viable Setup
- NiFi-Flow: RSSHub + Twitter API → NLP Service (NER + RTE) → Neo4j Graph → n8n Alert  
