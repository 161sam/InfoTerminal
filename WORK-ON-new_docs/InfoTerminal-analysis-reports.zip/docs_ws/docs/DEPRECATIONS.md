# Deprecated German Docs

The following pages are kept for reference and will be migrated to English:

- `docs/dev/Checkliste.md`
- `docs/runbooks/RUNBOOK-stack.md`
- `docs/runbooks/RUNBOOK-obs-opa-secrets.md`

Use English documentation moving forward.
