# Incident Report

- Start/End (UTC):
- Severity:
- Impact:
- Timeline:
- Root cause:
- Mitigations:
- Follow-ups / ADR needed:
