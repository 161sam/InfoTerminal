---
status: draft
owner: team-intel
last_updated: 2025-09-09
inputs:
  - Bilder & Videos (Social Media, News)
  - Metadata (EXIF, Hashes)
  - Reverse Image Search
pipelines:
  - Ingest von Media-Dateien
  - Forensische Analyse (Hash, EXIF, ELA)
  - ML: Deepfake Detection
  - Evidence Linking
outputs:
  - Echtheits-Reports
  - Visual Markierungen (Badges im Frontend)
  - Alerts bei Fake Media
privacy_ethics:
  - Schutz von Persönlichkeitsrechten
  - Nur forensische Datenanalyse
  - Keine Veröffentlichung sensibler Inhalte ohne Kontext
kpis:
  - Genauigkeit bei Fake-Erkennung
  - False Positive Rate
  - Anzahl geprüfter Medien pro Zeitraum
---

# Blueprint: Media Forensics Intelligence

## Ziel
Prüfung von Bildern & Videos auf Manipulation (Deepfakes, Fake News).

## Eingaben (Inputs)
- Social Media & News-Medien  
- Metadaten (EXIF, Hashes)  
- Reverse Image Search  

## Verarbeitung (Pipeline)
1. **Ingest** von Bildern/Videos  
2. **Forensische Analyse**: Hash, EXIF, ELA  
3. **ML**: Deepfake Detection  
4. **Evidence Linking** in Graph  

## Ergebnisse (Outputs)
- Echtheitsberichte  
- Badges im Frontend  
- Alerts bei Fake Media  

## KPIs & Erfolgskriterien
- Genauigkeit der Deepfake-Erkennung  
- False Positive Rate  
- Geschwindigkeit pro Analyse  

## Datenschutz & Ethik
- Schutz Persönlichkeitsrechte  
- Kontext zu Medien liefern  
- Keine Veröffentlichung sensibler Daten  

## Beispiel / Minimal Viable Setup
- NiFi: Social Media Feed → Media Forensics Service → Graph → Badge im Frontend  
