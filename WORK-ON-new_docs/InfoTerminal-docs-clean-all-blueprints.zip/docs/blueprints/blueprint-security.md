---
status: draft
owner: team-intel
last_updated: 2025-09-09
inputs:
  - Security-Feeds (CVE, NVD)
  - Threat-Intel-Reports
  - Logs & Alerts aus Observability
pipelines:
  - Ingest von Security-Daten
  - Normalisierung & Correlation
  - Graph: Schwachstellen ↔ Systeme ↔ Exploits
  - Alerts & Dashboards
outputs:
  - Security-Dossiers
  - Schwachstellen-Reports
  - Alerts für SOC-Teams
privacy_ethics:
  - Keine unnötigen PII speichern
  - Sicheres Logging (Vault/OPA)
  - Ethik-Checks bei Threat-Intel-Nutzung
kpis:
  - Anzahl erkannter Schwachstellen
  - MTTR (Mean Time to Remediation)
  - Abdeckung der Systeme
---

# Blueprint: Security Intelligence

## Ziel
Erkennung und Analyse sicherheitsrelevanter Vorfälle und Schwachstellen zur Unterstützung von SOC-Teams.

## Eingaben (Inputs)
- CVE/NVD-Feeds  
- Threat-Intel-Reports  
- Logs aus Observability (Prometheus, Loki)  

## Verarbeitung (Pipeline)
1. **Ingest** von Security-Feeds & Logs  
2. **Normalisierung** der Daten  
3. **Graph**: Systeme ↔ Schwachstellen ↔ Exploits  
4. **Alerts & Dashboards** für SOC  

## Ergebnisse (Outputs)
- Schwachstellenberichte  
- Security-Dossiers  
- Alerts bei kritischen Exploits  

## KPIs & Erfolgskriterien
- Abdeckung erkannter CVEs  
- Mean Time to Remediation (MTTR)  
- Anzahl erfolgreicher Alerts  

## Datenschutz & Ethik
- Kein unnötiges Sammeln von PII  
- Vault/OPA für Secrets & Policies  
- Transparenz bei Threat-Intel-Quellen  

## Beispiel / Minimal Viable Setup
- NiFi: CVE Feed + Logs → Graph-Views → Superset Security Dashboard  
