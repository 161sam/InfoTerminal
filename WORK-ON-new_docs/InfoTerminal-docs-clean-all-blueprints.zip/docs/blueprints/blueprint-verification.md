---
status: draft
owner: team-intel
last_updated: 2025-09-09
inputs:
  - News & Social Media Claims
  - Quellen-Metadaten (Domain, Reputation)
  - Evidence-Datenbanken
pipelines:
  - Claim Extraction
  - Evidence Retrieval & Reranking
  - RTE/Stance Classification
  - Aggregation & Human-in-the-Loop Review
outputs:
  - Veracity Badges
  - Evidence Panels
  - Auto-Dossiers
privacy_ethics:
  - Keine automatisierte Zensur
  - Human-in-the-Loop für finale Entscheidungen
  - Transparente Evidenzdarstellung
kpis:
  - Genauigkeit Claim/Evidence-Matching
  - Time-to-Verification
  - Nutzerfeedback bei Veracity Badges
---

# Blueprint: Verification Intelligence

## Ziel
AI-gestützte Verifikation von Nachrichten & Social Media Claims.

## Eingaben (Inputs)
- Nachrichten & Social Media Claims  
- Quellen-Metadaten  
- Evidenzdatenbanken  

## Verarbeitung (Pipeline)
1. **Claim Extraction** (NLP)  
2. **Evidence Retrieval & Reranking**  
3. **RTE/Stance Classification**  
4. **Aggregation & Review**  

## Ergebnisse (Outputs)
- Veracity Badges im Frontend  
- Evidence Panels für Analysten  
- Auto-Dossiers für Investigations  

## KPIs & Erfolgskriterien
- Genauigkeit der Verifikationen  
- Time-to-Verification  
- Nutzerfeedback  

## Datenschutz & Ethik
- Keine automatisierte Zensur  
- Human-in-the-Loop für finale Entscheidungen  
- Transparente Evidenzdarstellung  

## Beispiel / Minimal Viable Setup
- NiFi: News + Claims → NLP Claim Extraction → Evidence Retrieval → n8n Auto-Dossier  
