# Blueprints

Übersicht über alle Blueprints:

- [Aiethics Intelligence Blueprint](AIETHICS-INTELLIGENCE-BLUEPRINT.md)
- [Climate Intelligence Blueprint](CLIMATE-INTELLIGENCE-BLUEPRINT.md)
- [Cultural Intelligence Blueprint](CULTURAL-INTELLIGENCE-BLUEPRINT.md)
- [Disinfo Intelligence Blueprint](DISINFO-INTELLIGENCE-BLUEPRINT.md)
- [Economic Intelligence Blueprint](ECONOMIC-INTELLIGENCE-BLUEPRINT.md)
- [Financial Intelligence Blueprint](FINANCIAL-INTELLIGENCE-BLUEPRINT.md)
- [Flowise Agents Blueprint](FLOWISE-AGENTS-BLUEPRINT.md)
- [Geopolitical Intelligence Blueprint](GEOPOLITICAL-INTELLIGENCE-BLUEPRINT.md)
- [Health Intelligence Blueprint](HEALTH-INTELLIGENCE-BLUEPRINT.md)
- [Humanitarian Intelligence Blueprint](HUMANITARIAN-INTELLIGENCE-BLUEPRINT.md)
- [Legal Intelligence Blueprint](LEGAL-INTELLIGENCE-BLUEPRINT.md)
- [Mediaforensics Intelligence Blueprint](MEDIAFORENSICS-INTELLIGENCE-BLUEPRINT.md)
- [Security Blueprint](SECURITY-BLUEPRINT.md)
- [Supplychain Intelligence Blueprint](SUPPLYCHAIN-INTELLIGENCE-BLUEPRINT.md)
- [Technology Intelligence Blueprint](TECHNOLOGY-INTELLIGENCE-BLUEPRINT.md)
- [Terrorism Intelligence Blueprint](TERRORISM-INTELLIGENCE-BLUEPRINT.md)
- [Verification Blueprint](VERIFICATION-BLUEPRINT.md)
