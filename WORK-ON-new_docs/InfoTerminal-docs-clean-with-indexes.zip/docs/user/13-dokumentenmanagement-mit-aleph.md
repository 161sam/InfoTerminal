# 13. Dokumentenmanagement mit Aleph

**Aleph** ist in InfoTerminal der zentrale Baustein für **Dokumentenmanagement und Investigations**.
Es ermöglicht die Verarbeitung, Analyse und Verknüpfung von unstrukturierten Dokumenten.

---

## 13.1 Funktionen

- **Upload & Ingest**: Dateien, Archive und Web-Datenquellen importieren
- **OCR**: Texterkennung aus PDFs und Scans (via Tesseract)
- **Sprache erkennen**: automatische Language ID
- **NER & Fingerprinting**: Extraktion von Personen, Organisationen und Beziehungen
- **Verknüpfungen**: Dokumente werden automatisch mit Graph- und Suchindex verbunden

---

## 13.2 Nutzung in InfoTerminal

### Upload

- Über das Frontend → „Dokumenten-Upload“
- Über NiFi-Pipeline → Dateien aus Watch-Folder, Cloud-Speicher oder API ziehen

### Analyse

- OCR wird automatisch ausgeführt, falls kein Text vorhanden ist
- Entities (Personen, Orte, Organisationen) erscheinen in der Graph-Ansicht
- Fingerprinting (Shingling) erkennt Duplikate und Überschneidungen

### Suche

- Dokumente sind sofort in der **Search API** verfügbar
- Ergebnisse enthalten Metadaten (Quelle, Entitäten, Sprache, Datum)
- Querverweise zu Graph-Analysen

---

## 13.3 Best Practices

- Möglichst **strukturierte Dokumente** (Text-PDF statt Bild-PDF) hochladen → bessere OCR-Ergebnisse
- Upload-Ordner klar strukturieren (z. B. `contracts/`, `reports/`, `emails/`)
- Ergebnisse immer mit **Graph-Analyse** kombinieren, um Beziehungen sichtbar zu machen

---
