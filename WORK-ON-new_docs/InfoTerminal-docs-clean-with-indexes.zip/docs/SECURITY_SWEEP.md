# Security Sweep (Dev)

- TODO: Secrets rotieren (Keycloak admin, oauth2-proxy cookie, DB-Passwörter).
- TODO: TLS/Ingress für Prod (Cert-Manager).
- TODO: Backups für PG/OpenSearch/Neo4j.
