## 30. CLI – WaveTerm Features (planned)

- [ ] **[CLI-WT-1]** `it waveterm open` – WaveTerm Instanz öffnen (Browser/Panel)
- [ ] **[CLI-WT-2]** `it waveterm send` – Kommando in aktiven Workspace senden
- [ ] **[CLI-WT-3]** `it waveterm case` – Case-Verzeichnis mounten/attachen
- [ ] **[CLI-WT-4]** `it waveterm export` – Session/Artefakte → Dossier-Appendix
- [ ] **[CLI-WT-5]** Vault-/Token-Handling für WaveTerm-Kommandos
- [ ] **[CLI-WT-6]** OPA-Policies für WaveTerm-CLI-Befehle
- [ ] **[CLI-WT-7]** Roundtrip-Tests (CLI → WaveTerm → Artefakte → Dossier)
