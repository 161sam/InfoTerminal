# InfoTerminal Documentation

Willkommen im Dokumentations-Portal. Schnellzugriffe auf die Hauptbereiche:

- [User](user/)
- [Dev](dev/)
- [Adr](adr/)
- [Architecture](architecture/)
- [Blueprints](blueprints/)
- [Presets](presets/)
- [Dossiers](dossiers/)
- [Api](api/)
- [Runbooks](runbooks/)
- [Screenshots](screenshots/)

> Hinweis: Benutzer-Dokumentation ist **Deutsch**, Entwickler- & API-Dokumentation **Englisch**.
