# Presets & Profiles

Liste der verfügbaren Preset-Profile:

- `agency.yaml`
- `climate_researcher.yaml`
- `compliance_officer.yaml`
- `crisis_analyst.yaml`
- `disinfo_watchdog.yaml`
- `economic_analyst.yaml`
- `journalism.yaml`
- `research.yaml`
